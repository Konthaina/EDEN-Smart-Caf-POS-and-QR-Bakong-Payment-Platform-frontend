<template>
  <div class="print-area">
    <div class="receipt-container w-[280px] mx-auto bg-white p-4 text-[13px] font-mono text-black shadow-none">
      <!-- Logo & Cafe Name -->
      <div class="text-center mb-2">
        <img src="/logo.png" alt="Cafe Logo" class="mx-auto h-12 mb-1" />
        <h2 class="text-lg font-bold uppercase tracking-wide">Eden Coffee</h2>
        <p class="text-xs text-gray-500">Fresh. Fast. Friendly.</p>
      </div>

      <!-- Order Info -->
      <div class="text-center text-xs mb-2">
        <p>{{ $t("receipt.order_id") }}: #{{ String(orderId).padStart(3, "0") }}</p>
        <p>{{ $t("receipt.printed") }}: {{ now }}</p>
      </div>

      <!-- Table Head -->
      <div class="border-t border-b border-gray-300 py-1 text-sm font-semibold mb-1 flex justify-between">
        <span>Qty</span>
        <span class="w-[120px] text-left">Item</span>
        <span class="text-right">Amount</span>
      </div>

      <!-- Item List -->
      <div v-for="item in cart" :key="item.id" class="text-sm mb-1">
        <div class="flex justify-between">
          <span>x{{ item.qty }}</span>
          <span class="truncate w-[120px] text-left">{{ item.name }}</span>
          <span class="text-right">${{ format(item.price * item.qty) }}</span>
        </div>
        <div class="text-xs text-gray-500 flex justify-between mb-1 pl-2">
          <span class="italic">@ ${{ format(item.price) }}</span>
          <span class="text-right">Subtotal</span>
        </div>
      </div>

      <hr class="my-2 border-dashed border-gray-400" />

      <!-- Totals -->
      <div class="flex justify-between text-sm">
        <span>{{ $t("receipt.subtotal") }}</span>
        <span>${{ format(total) }} USD</span>
      </div>

      <div v-if="discount && discount.value" class="flex justify-between text-green-700 text-sm">
        <span>{{ $t("receipt.promo_discount") }}</span>
        <span>-{{ discountText }}</span>
      </div>

      <div v-if="manualDiscount > 0" class="flex justify-between text-green-700 text-sm">
        <span>{{ $t("receipt.manual_discount") }}</span>
        <span>-{{ manualDiscount }}%</span>
      </div>

      <div class="flex justify-between font-bold text-base border-t border-black mt-2 pt-2">
        <span>{{ $t("receipt.total") }}</span>
        <span>${{ format(discountedTotal) }} USD</span>
      </div>

      <!-- Footer Info -->
      <div class="mt-4 text-xs text-center text-gray-700">
        <p>{{ $t("receipt.pay_by") }}: <span class="capitalize">{{ selectedMethod }}</span></p>
        <p>{{ $t("receipt.cashier") }}: {{ user?.name || $t("receipt.unknown") }}</p>
      </div>

      <div class="mt-3 text-xs text-center text-black font-medium tracking-wide">
        {{ $t("receipt.thanks") }} ❤️
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue';

const props = defineProps({
  cart: { type: Array, required: true },
  user: { type: Object, required: false },
  selectedMethod: { type: String, required: true },
  orderId: { type: [Number, String], required: true },
  total: { type: Number, required: true },
  discount: { type: Object, default: () => ({}) },
  manualDiscount: { type: Number, default: 0 },
  discountedTotal: { type: Number, required: true },
});

const now = new Date().toLocaleString();

const format = (v) => parseFloat(v).toFixed(2);

const discountText = computed(() => {
  if (!props.discount || !props.discount.value) return "";
  return props.discount.type === "percent"
    ? `${props.discount.value}%`
    : `$${props.discount.value}`;
});
</script>

<style scoped>
.print-area {
  display: none;
}

@media print {
  .print-area {
    display: flex !important;
    position: fixed !important;
    inset: 0;
    background: white;
    width: 100vw;
    height: 100vh;
    z-index: 9999;
    justify-content: center;
    align-items: flex-start;
    padding-top: 10px;
  }

  .receipt-container {
    box-shadow: none !important;
  }

  body, html {
    background: white !important;
    margin: 0 !important;
    padding: 0 !important;
    height: auto !important;
    overflow: visible !important;
  }

  body * {
    visibility: hidden !important;
  }

  .print-area,
  .print-area * {
    visibility: visible !important;
  }
}
</style>
